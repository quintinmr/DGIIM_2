/**
 * @author Quintín Mesa Romero 2º DGIIM
 */

#include <iostream>
#include <vector>
using namespace std;

/**
 * @brief Ejercicio 41
 * Ejercicio en el que se pide implementar una función void la cual, dado un nivel del Triángulo de Tartaglia, introduce
 * en un vector dinámico los números de dicho triángulo para un nivle dado como argumeto.
 * Se han implementado dos funciones auxiliares que se usan en la función que nos pide implementar el ejercicio: una función
 * recursiva para el cálculo del factorial de un número y otra para el cálculo de un número combinatorio (que son al fin y
 * al cabo los elemenntos que constituyen el triángulo de Tartaglia
 */

/**
 * @brief Función que introduce en un vector todos los elemetos del tríangulo de Tartaglia para un nivel determinado
 * @param nivel Nivel del triángulo de Tartaglia a considerar
 * @param v Vector en el que se van a introducir los elementos del triángulo hasta el nivel indicado, incluído.
 * @pre nivel >= 0
 * @pre v ha de estar vacio
 */

int factorial (int n){
    int fact;
    if (n <= 1)fact = 1;
    else
        fact = n * factorial(n-1);

    return fact;
}

int combinacion (int a, int b){
    return (factorial(a) / (factorial(b) * factorial(a-b)));
}

void tartaglia (int nivel, vector <unsigned int> &v){

    for (int i = 0; i <= nivel; i++){
        for (int j = 0; j <= i; j++){
            v.push_back(combinacion(i,j));
        }
    }

}


int main ()
{

   vector <unsigned int> vect;
    int nivel;

    cout << "Introduzca el nivel del tirángulo de Tartaglia que desea visualizar: " << endl;

    cin >> nivel;

    tartaglia(nivel, vect);

    for (int i = 0; i < vect.size(); i++){
        cout << vect.at(i) << " ";
    }

    cout << endl;

    return 0;
}

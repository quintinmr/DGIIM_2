/**
 * @author Quintín Mesa Romero 2º DGIIM
 */

#include <list>
#include <algorithm>
#include <iostream>
using namespace std;

/**
 * @brief Ejercicio 31
 * Ejercicio que consiste en implementar una función que lleva a cabo el duplicado de una lista intercalando tras cada elemento
 * en la posición i, el elemento que se encuentra en la posición n-i-1, donde i se encuentra variando entre 0 y n-1
 */

/**
 * @brief Función que duplica una lista dada como argumento
 * El duplicado de la lista se realiza intercalando alternativamente tras cada elemento en la posición  i, el elemento
 * que está en la posición n-i-1, con i={0,1,...,n-1}
 * @param L Lista a duplicar
 * @pre La lista debe contener al menos un elemento
 * @post La lista introducida es modificada
 */

template <class T>
void duplicarlista (list<T> & L)
{
    list <T> aux1,aux2;

    while (!L.empty()){
        if (L.size() != 1) {
            aux1.push_back(L.front());
            aux1.push_back(L.back());
            L.pop_front();
            L.pop_back();
        }
        else {
            aux1.push_back(L.front());
            L.pop_front();
        }
    }

   aux2 = aux1;
    L = aux1;

    while (!aux2.empty()){
        L.push_back(aux2.back());
        aux2.pop_back();
    }

}


int main (int argc, char *argv[])
{

    list <int> lista;

    for(int i = 1; i < argc; i++){

        lista.push_back(atoi(argv[i]));
    }

    cout << "Lista inicial:" << endl;
    for (auto iter = lista.begin(); iter != lista.end(); iter++){
        cout << *iter << " ";
    }

    duplicarlista(lista);

    cout << endl;
    cout << "Lista duplicada:" << endl;
    for (auto iter = lista.begin(); iter != lista.end(); iter++){
        cout << *iter << " ";
    }

    return 0;
}




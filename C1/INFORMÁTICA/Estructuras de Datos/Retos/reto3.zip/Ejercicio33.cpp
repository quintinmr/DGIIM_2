/**
 * @author Quintín Mesa Romero 2º DGIIM
 */
#include "Ejercicio33.h"
#include <iostream>
#include <list>
#include <algorithm>
using namespace std;

/**
 * @brief Ejercicio que consiste en la implementación de una función que calcula la distancia entre las posiciones del
 * máximo y mínimo de una lista, teniendo en cuenta tanto si uno se encuentra antes que el otro y si aparecen más de
 * una vez en la lista.
 * No se pueden usar estructuras auxiliares
 */
/**
 * @brief Función que devuelve la distancia entre la posición del mínimo elemento y el máximo elemento de la lista
 * Si el mínimo se encuentra antes que el máximo en la lista, la distancia es positiva. En caso contrario la distancia es
 * negativa. Si el mínimo aparece más de una vez en la lista, la posición que cogemos es la de la primera ocurrencia. Si lo
 * mismo ocurre con el máximo, se coge la posición de la última ocurrencia del mismo.
 * @param L Lista sobre la que se va a trabajar
 * @pre La lista debe contener al menos un elemento
 * @return distancia a la que se encuentran las posiciones del mínimo y el máximo de la lista
 * @post La lista no es modificada
 */

int dminmax (list<int> & L){

    int min = L.front();
    int max = L.front();
    int distancia;
    int o = 0;
    int p = L.size()-1;

    // Calculamos el máximo y el mínimo de la lista
   for (list<int>::iterator i = L.begin(); i != L.end(); i++) {
       if (min > *i) {
           min = *i;
       }
       if (max < *i){
           max = *i;
       }
   }

    list <int>::iterator j,w;
    j = L.begin(), w = L.end().operator--();

    // Calculamos la posición del mínimo en la lista (primera ocurrencia) y la guardamos en o.
    while (*j != min){
        o++;
        j++;
    }

    // Calculamos la posición del máximo en la lista (última ocurrencia).
    // Empezamos recorriendo la lista desde el final, de tal forma que la posición de la primera ocurrencia del máximo
    // en este orden de lectura, es la que guardamos es p
    while (*w != max) {
        p--;
        w--;
    }

    if (o > p) distancia = p-o;
    else distancia = p-o;

   return distancia;

}


int main (int argc, char *argv[])
{

    list <int> lista;
    int distance;

    for(int i = 1; i < argc; i++){

        lista.push_back(atoi(argv[i]));
    }

    cout << "Lista inicial:" << endl;
    for (list<int>::iterator iter = lista.begin(); iter != lista.end(); iter++){
        cout << *iter << " ";
    }

    distance = dminmax(lista);

   cout << endl;
   cout << "La distancia entre el mínimo elemento y el máximo elemento es: " << distance;
   cout << endl;

    return 0;
}


/**
 * @author Quintín Mesa Romero 2º DGIIM
 */

#include <iostream>
#include <list>

using namespace std;

/**
 * @brief Ejercicio 32
 * Ejercicio que consiste en la implementación de una función que se encarga de trasladar los n primeros elementos (n pasado
 * como argumento) de una lista al final de la misma.
 */

/**
 * @brief Función que traslada los n primeros elementos de la lista al final de la misma
 * @param L Lista con la que se va a trabajar
 * @param n Número de elementos a trasladas al final de la lista (contando desde el primero en adelante)
 * @pre L ha de contener al menos un elemento
 * @pre n >= 0
 * @post La lista introducida como parámetro es modificada
 */

void rotalista(list<int> & L, int n){

    list <int> aux;

    for (int i = 0; i < n; i++){
        aux.push_back(L.front());
        L.pop_front();
    }

    while (!aux.empty()){
        L.push_back(aux.front());
        aux.pop_front();
    }

}


int main (int argc, char *argv[])
{
    list <int> l;
    int n;

    for(int i = 1; i < argc; i++){

        l.push_back(atoi(argv[i]));
    }

    cout << "Lista inicial:" << endl;
    for (list<int>::iterator iter = l.begin(); iter != l.end(); iter++){
        cout << *iter << " ";
    }
    cout << endl;

    cout << "Introduzca el número de elementos que desea rotar: " << endl;
    cin >> n;

    rotalista(l,n);

    cout << "Lista rotada:" << endl;
    for (list<int>::iterator it = l.begin(); it != l.end(); it++){
        cout << *it << " ";
    }

    cout << endl;

    return 0;
}




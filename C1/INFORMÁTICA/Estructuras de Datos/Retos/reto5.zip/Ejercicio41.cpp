/**
 * @author Quintín Mesa Romero 2º DGIIM
 * @brief Programa de prueba para la función que se pide implementar en el ejercicio 41
 */

#include <iostream>
#include "bintree.h"

using namespace std;

/**
 * @brief Funcion que calcula el nivel de un nodo de un árbol
 * @param w nodo cuyo nivel queremos hallar.
 * @param A Arbol en el que se va a buscar dicho nivel.
 * @return nivel en el que se encuentra el nodo
 * @return -1 si el nodo no es del árbol
 */
int enquenivel (bintree<int>:: node w, bintree<int> & nodo);

/**
 * @brief Función que calcula el nivel de un nodo, pero trabajando a nivel de nodos directamente
 * @param w nodo cuyo nivel queremos hallar.
 * @param nodo nodo del árbol en el que se va a buscar el nivel
 * @return nivel en el que se encuentra el nodo.
 * @return -1 si el nodo no es del árbol.
 */
int enquenivel (bintree<int>:: node w, bintree<int>::node A);

int enquenivel (bintree<int>:: node w, bintree<int> & A) {

    return enquenivel(w, A.root());

}

int enquenivel (bintree<int>:: node w, bintree<int>::node A) {

    int nivel = -1;
    bool cond1 = !A.left().null() && !A.right().null() && A.left() != w && A.right() != w;
    bool cond2 = !A.left().null() && A.left() != w;
    bool cond3 = !A.right().null() && A.right() != w;

    if (w == A)
        return nivel++;

    int nodo1, nodo2;

    if (A.right() == w || A.left() == w) {
        return nivel+2;
    }
    else if (cond1) {
        nodo1 = enquenivel(w,A.left());
        nodo2 = enquenivel(w,A.right());
        if (nodo1>nodo2)
            nivel = nodo1;
        else nivel = nodo2;
    }
    else if (cond2) {
        nivel = enquenivel(w,A.left());
    }
    else if (cond3) {
        nivel = enquenivel(w,A.right());
    }

    if (nivel != -1)
        ++nivel;

    return nivel;
}

int main () {

    // Creamos el árbol
    bintree<int> Arb(9);
    Arb.insert_left(Arb.root(), 3);
    Arb.insert_right(Arb.root(), 5);
    Arb.insert_left(Arb.root().left(), 0);
    Arb.insert_right(Arb.root().left(), 1);
    Arb.insert_right(Arb.root().left().right(), 3);
    Arb.insert_left(Arb.root().right(), 4);

    // Buscamos el nivel
    cout << enquenivel(Arb.root().left().right(), Arb) << endl;

    return 0;
}

#!/bin/bash

echo "" >> salida_Ej1Obv.dat
i=10000
a=2000000

while [ $i -lt $a ]
do
	./Ejercicio1_Obvio $i >> salida_Ej1Obv.dat
	let i+=79600
done


/**
 * @author Quintín Mesa Romero 2º DGIIM
 */

#include <list>
#include <algorithm>
#include <iostream>
using namespace std;

/**
 * @brief Ejercicio 34
 * Ejercicio que consiste en la implementación de una función que compara dos listas de enteros devolviendo el valor booleano
 * true si la primera lista pasada como argumento es mayor que la segunda en sentido lexicogáfico y false en caso contrario.
 * Se han tenido en cuenta los casos en los que las listas son iguales y una lista está contenida en otra.
 */

/**
 * @brief Función que compara dos listas
 * @param L1 primera lista pasada como argumento
 * @param L2 segunda lista pasada como argumento
 * @pre Las listas han de contener al menos un elemento
 * @return true si L1 > L2, false en caso contrario
 */

bool lexicord (list <int> L1, list <int> L2) {

    bool mayor;

    if (std::includes(L1.begin(), L1.end(), L2.begin(), L2.end())) {
        mayor = true;
    }
    else {
        if (L1 == L2) mayor = false;
        else {
            while (!L1.empty() && !L2.empty()) {
                if (L1.front() > L2.front()) mayor = true;
                else mayor = false;

                L1.pop_front();
                L2.pop_front();
            }
        }
    }

    return mayor;
}

int main ( )
{

    list <int> lista1,lista2;
    int n;

    cout << "Introduzca los elemento de la lista L1. Introduzca -1 para terminar: " << endl;

    while ((cin >> n) && (n != -1) ){
        lista1.push_back(n);
    }

    cout << endl;
    cout << "Introduzca los elemento de la lista L2.Introduzca -1 para terminar: " << endl;

    while ((cin >> n) &&  (n != -1)){
        lista2.push_back(n);
    }

    cout << "Lista 1:" << endl;
    for (auto iter = lista1.begin(); iter != lista1.end(); iter++){
        cout << *iter << " ";
    }

    cout << endl;
    cout << "Lista 2:" << endl;
    for (auto iter = lista2.begin(); iter != lista2.end(); iter++){
        cout << *iter << " ";
    }

    cout << endl;

    if (lexicord(lista1, lista2)) cout << "La lista 1 es mayor que la lista 2" << endl;
    else cout << "La lista 2 es mayor que la lista 1";

    return 0;
}

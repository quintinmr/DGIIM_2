/**
 * @author Quintín Mesa Romero 2º DGIIM
 * @brief Porgrama de prueba de la función requerida en el ejercicio 32
 */

#include <iostream>
#include "bintree.h"

using namespace std;

/**
 * @brief Funcion que se encarga de comprobar si un árbol es subarbol de otro.
 * @param ab1 arbol en el que se va a llegar a cabo la comprobación.
 * @param ab2 subarbol que queremos buscar.
 * @return true si el ab2 es subarbol de ab1.
 * @return false en caso contrario.
 */
bool es_subarbol(const bintree<int> &ab1, const bintree<int> &ab2);

/**
 * @brief Funcion que comprueba si un nodo dado y sus correspondientes hijos tienen los mismos valores de las etiquetas.
 * @param nodo1 nodo del árbol 1.
 * @param nodo2 nodo del árbol 2.
 * @return true si los nodos tienen los mismos valores.
 * @return false en caso contrario.
 */
bool eq_nodos(bintree<int>::node n1, bintree<int>::node n2);

bool es_subarbol(const bintree<int> &ab1, const bintree<int> &ab2) {

    bool resultado;

    // Definimos los áboles con los que vamos a trabajar
    bintree<int> left, right, arbol;

    // Definimos dos nodos en el que vamos a almacenar las raíces de los arboles pasados como argumento
    bintree<int>::node nodo1, nodo2;
    nodo1 = ab1.root();
    nodo2 = ab2.root();

    // Si las raíces son nulas, necesariamente, la función devuelve ture
    if (nodo1.null() && nodo2.null()) return true;
    // Si alguno de los árboles está vacío y el otro no, la función, claramente devuelve false
    if (nodo1.null() || nodo2.null()) return false;
    // Si las raices existen, comprobamos si los demás nodos coinciden. Para ello hacemos uso de la función eq_nodos
    // que va a comprobar si los nodos, partiendo de las raíces, tienen valores iguales
    if (eq_nodos(nodo1, nodo2)) return true;

    left.assign_subtree(ab1, ab1.root().left());
    right.assign_subtree(ab1, ab1.root().right());
    arbol.assign_subtree(ab2, ab2.root());


    return  (es_subarbol(left, arbol) || es_subarbol(right, arbol));;
}

bool eq_nodos(bintree<int>::node nodo1, bintree<int>::node nodo2) {
    if (nodo1.null() && nodo2.null()) return true;
    if (nodo2.null() || nodo1.null()) return false;
    bool result = (*nodo1 == *nodo2 && eq_nodos(nodo1.left(), nodo2.left()) &&
                   eq_nodos(nodo1.right(), nodo2.right()));
    return (result);
}


int main() {

    // Definimos el árbol con el que vamos a trabajar
    bintree<int> ab1(6), ab2(9);

    // Construimos el primer arbol
    ab1.insert_left(ab1.root(), 1);
    ab1.insert_right(ab1.root(), 9);
    ab1.insert_left(ab1.root().left(), 7);
    ab1.insert_right(ab1.root().left(), 5);
    ab1.insert_right(ab1.root().left().right(), 3);
    ab1.insert_left(ab1.root().right(), 1);

    // Construimos el segundo árbol
    ab2.insert_left(ab2.root(), 7);
    ab2.insert_right(ab2.root(), 5);
    ab2.insert_right(ab2.root().right(), 2);

    bool result = es_subarbol(ab1, ab2);
    if (result) cout << "El segundo arbol esta contenido en el primero" << endl;
    else cout << "El segundo arbol no esta contenido en el primero" << endl;

    return 0;
}



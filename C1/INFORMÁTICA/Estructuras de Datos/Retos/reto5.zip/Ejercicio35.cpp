/**
 * @author Quintín Mesa Romero 2º DGIIM
 * @brief Programa de prueba para la función que se nos pide en el ejerccio 35 de la relación
 */

#include <iostream>
#include "bintree.h"

using namespace std;

/**
 * @brief Funcion que dados 2 arboles binarios A y B con la misma estructura de ramificación, devuelve un árbol binario con
 * la misma estructura y cuyas etiquetas sean la suma los valores de las etiquetas de A Y B
 * etiquetas en la misma posicion.
 * @param A Arbol sumando 1.
 * @param B Arbol sumando 2.
 * @param C Arbol suma.
 */
void sumadosarboles(bintree<int> A, bintree<int> B, bintree<int> &C);

/**
 * @brief Funcion que comprueba si dos árboles concretos tienen la misma estructura de ramificacion
 * Es una función recursiva
 * @param A arbol 1 a comparar.
 * @param B arbol 2 a comparar.
 * @return true si los dos árboles tienen la misma estructura de ramificación
 * @return false en caso contrario.
 */
bool igual_estructura_ram(bintree<int>::node A, bintree<int>::node B);

void sumadosarboles(bintree<int> A, bintree<int> B, bintree<int> &C) {

    // En el caso en el que los dos árboles tengan la misma estructura de ramificación, se podrá proceder a la
    // suma de los mismos, en caso cntrario, no se hará nada
    if (igual_estructura_ram(A.root(),B.root())) {

        // Aprovechamos el operador de asignación del bintree y asignamos al árbol suma, el árbol A, para
        // a continuación sumar las etiquetas de B a las de C
        C = A;

        // Creamos dos iteradores que recorran en preorden el árbol C y el B
        bintree<int>::preorder_iterator i = C.begin_preorder();
        bintree<int>::preorder_iterator j = B.begin_preorder();

        // Hacemos la suma
        for (j, i; i != C.end_preorder(); ++j, ++i)
            *i += *j;
    }
}

bool igual_estructura_ram(bintree<int>::node A, bintree<int>::node B) {

    bool result = false;
    if (A.null() && B.null()) return true;
    if (!A.null() && !B.null()) {
        return (igual_estructura_ram(A.left(), B.left()) &&
                igual_estructura_ram(A.right(), B.right()));
    }
    return result;
}


int main(int argc, char *argv[]) {

    // Definimos los árboles

    bintree<int> A(3);
    bintree<int> B(10);
    bintree<int> C;

    // ÁRBOL A
    A.insert_left(A.root(), 6);
    A.insert_right(A.root(), 9);
    A.insert_right(A.root().left(), 8);
    A.insert_right(A.root().right(), 4);

    // ÁRBOL B
    B.insert_left(B.root(), 3);
    B.insert_right(B.root(), 11);
    B.insert_right(B.root().left(), 8);
    B.insert_right(B.root().right(), 7);

    // Sumamo los árboles
    sumadosarboles(A, B, C);

    // Mostramos el árbol suma
    bintree<int>::preorder_iterator it;
    for (it = C.begin_preorder(); it != C.end_preorder(); ++it)
        cout << *it << " ";
    cout << endl;

    return 0;
}


